Meg’s Get Sh*t Done List! — Final Bundle

Included files:
- notion_weekly_rotation.csv — Import into Notion to create your 7-day cleaning + reward system.
- index.html / styles.css / app.js / manifest.json / sw.js / icon.svg — Full web app package (PWA ready).

How to use:
1. To use locally, open index.html in any browser.
2. To host, upload the full folder to Netlify (app.netlify.com/drop) or GitHub Pages.
3. For Notion: In Notion, click “Import” → “CSV” → upload notion_weekly_rotation.csv.

You’re all set, Meg — go get sh*t done! 💪
